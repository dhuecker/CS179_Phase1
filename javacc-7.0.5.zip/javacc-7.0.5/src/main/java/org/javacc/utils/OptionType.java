package org.javacc.utils;


/**
 * 
 * 
 * @author Chris Ainsley
 *
 */
public enum OptionType {
	  BOOLEAN,
	  INTEGER,
	  STRING; 
}