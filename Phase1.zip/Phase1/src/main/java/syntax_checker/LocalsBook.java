package syntax_checker;

public class LocalsBook extends Book {

    public LocalsBook() {

    }
}
