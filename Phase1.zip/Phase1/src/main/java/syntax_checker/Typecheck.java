package syntax_checker;

import syntaxtree.*;
import parser.*;

import java.util.ArrayList;
import java.util.List;

public class Typecheck {
  public static SymbolTable sTable;

  // Take input here
  public static MiniJavaParser parser = new MiniJavaParser(System.in);

  public static void typeCheck() {
    // Set up data below
    sTable = new SymbolTable();
    SymbolTableConstructor oneVisitor = new SymbolTableConstructor();
    CheckVisitor<String> twoVisitor = new CheckVisitor<>();

    parser.ReInit(System.in);

    try {
      Goal root = parser.Goal();

      // First pass; Give the visitor data it needs
      oneVisitor.root = root;
      oneVisitor.symbolTable = sTable;

      // Construct symbol table
      root.accept(oneVisitor);

      // Check to make sure class refs are not circular
      Graph classGraph = new Graph();
      List<String> classes = sTable.hashTable.getAllItems();
      for (int i = 0; i < classes.size(); i++) {
        ClassBook cb = (ClassBook) sTable.get(Symbol.symbol(classes.get(i)));
        classGraph.addEdge(cb.parent, classes.get(i));
      }

      if (!classGraph.acyclic()) {
        oneVisitor.errorFound = true;
      } else {

        // Second pass
        twoVisitor.root = root;
        twoVisitor.symbolTable = sTable;

        // Type check based off items stored in the symbol table
       root.accept(twoVisitor);
      }
    } catch (Exception e) {
      System.out.println("ERROR: " + e);
      e.printStackTrace();
    }

    // If the program makes it this far, it is correct
    if (!oneVisitor.errorFound && ! twoVisitor.errorFound) {
      System.out.println("Program type checked successfully");
    }
    else {
      System.out.println("Type error");
    }
  }

  public static void main(String args[]) {
    typeCheck();
  }
}

class Graph {
  List<GraphNode> nodes;

  public Graph() {
    nodes = new ArrayList<>();
  }

  // Adds edge: n1 -> n2
  public void addEdge(String n1_key, String n2_key) {
    if (n1_key != null) {
      addNode(n1_key).next = addNode(n2_key);
    } else {
      addNode(n2_key);
    }
  }

  public void print() {
    GraphNode curr = nodes.get(0);

    while (curr != null && !curr.visited) {
      System.out.print(curr.value + " -> ");
      curr.visited = true;
      curr = curr.next;
    }
  }

  public boolean acyclic() {
    GraphNode current = nodes.get(0);

    while (current != null && !current.visited) {
      if (current.next != null && current.next.visited) return false;

      current.visited = true;
      current = current.next;
    }

    return true;
  }

  GraphNode addNode(String key) {
    GraphNode n = find(key);
    if (n != null || key == null)
      return n;

    GraphNode g = new GraphNode(key);
    nodes.add(g);
    return g;
  }

  GraphNode find(String key) {
    for (int i = 0; i < nodes.size(); i++) {
      if (key != null && nodes.get(i).value.equals(key))
        return nodes.get(i);
    }

    return null;
  }

}

class GraphNode {

  public String value;
  public GraphNode next;
  public boolean visited;

  public GraphNode(String value) {
    this.value = value;
    visited = false;
  }

  public void print() {
    if (next != null)
      System.out.println(value + " -> " + next.value);
    else
      System.out.println(value);
  }

}