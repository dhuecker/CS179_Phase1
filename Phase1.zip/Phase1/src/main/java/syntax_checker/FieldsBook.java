package syntax_checker;

public class FieldsBook extends Book {

    public FieldsBook() {

    }
}
