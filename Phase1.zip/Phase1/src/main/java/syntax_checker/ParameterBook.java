package syntax_checker;

public class ParameterBook extends Book {
    public ParameterBook() {

    }
}
