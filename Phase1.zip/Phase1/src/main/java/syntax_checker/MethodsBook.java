package syntax_checker;

import java.util.ArrayList;
import java.util.List;

public class MethodsBook extends Book {

    TypeBook type;
    int paramNum;
    List<String> pTypes;

    public MethodsBook() {
        pTypes = new ArrayList<>();
    }
}
