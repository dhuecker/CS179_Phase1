package syntax_checker;

public class ClassBook extends Book {

    String classname;
    SymbolTable methods;
    String parent;

    public ClassBook(String cname) {
        classname = cname;
        methods = new SymbolTable();
    }
}
